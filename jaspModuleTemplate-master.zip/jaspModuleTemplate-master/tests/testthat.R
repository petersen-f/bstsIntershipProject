library(jaspTools)
library(testthat)

jaspTools::runTestsTravis(module = getwd())
